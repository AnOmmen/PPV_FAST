//--------------------------------------------------------------------------------
// Game
// Written By: Justin Murphy
//
// Overall game class, this class creates, holds and manipulates 
// all objects and any non framework subsystems
//--------------------------------------------------------------------------------
#ifndef Game_h
#define Game_h
//--------------------------------------------------------------------------------
#include "Application.h"
#include "AudioSystemWwise.h"
#include "Entity3D.h"
#include "EventManager.h"
//--------------------------------------------------------------------------------
class Camera;
class InputController;
//--------------------------------------------------------------------------------
class CGame : public CApplication {
public:
	int GetWindowWidth()const { return m_nWindowWidth; }
	int GetWindowHeight()const { return m_nWindowHeight; }

	virtual void Pause();
	virtual void UnPause();

	void Show_Cursor();
	void Hide_Cursor();

	CGame();
	~CGame();
private:
	// some default objects
	//TODO: MAKE OBJECT MANAGEMENT LESS HARDCODED
	Entity3D				m_Entity1;
	Entity3D				m_Entity2;
	// default view
	Camera*					m_pCamera;
	//Input Controller
	InputController *		m_pInput;
	
	// audio stuff
	AudioSystemWwise		g_AudioSystem;
	
	float				volume;
	//Adjust Audio Scale
	//NOTE: only do this to get the placeholder bank integrated with your engine,
	//once you are ready to recieve a real soundbank tell the Sound Engineer the scale you are using
	float				AudioScaling;


	static bool			m_bShowCursor;
	static bool			m_bKeepCursorPos;
	POINT				m_InitialCursorPos; // used to reset the cursor to the correct position after click is released

	virtual void DoFrame(float timeDelta, float totaltime);
	virtual void DoIdleFrame( float timeDelta, float totaltime );
	virtual void SceneInit();
	virtual void SceneEnd();
	
	void Update(float timeDelta, float totaltime);
	void Render(); 

	//Input Functions
	void VolumeUp(const CGeneralEventArgs<float>& args);
	void VolumeDown(const CGeneralEventArgs<float>& args);
	void WorldScaleUp(const CGeneralEventArgs<float>& args);
	void WorldScaleDown(const CGeneralEventArgs<float>& args);
	void Play3DSound(const CGeneralEventArgs<float>& args);
	void Play3DSoundNoParam(const CGeneralEventArgs<float>& args);
	//play/stop music track
	//NOTE: multiple instances can be played, calling stop will stop all of them
	void PlayMusic(const CGeneralEventArgs<float>& args);
	void StopMusic(const CGeneralEventArgs<float>& args);

	void StopGame(const CGeneralEventArgs<float>& args);
};
//--------------------------------------------------------------------------------
#endif // Game_h
//--------------------------------------------------------------------------------