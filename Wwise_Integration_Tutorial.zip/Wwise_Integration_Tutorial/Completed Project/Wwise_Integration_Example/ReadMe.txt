Wwise_Integration_Example.exe

Requires:
Visual C++ 2013 Runtime
http://www.microsoft.com/en-gb/download/details.aspx?id=40784
DirectX 9 End User Runtime (required for XInput)
http://www.microsoft.com/en-us/download/details.aspx?id=35

Written By:
Justin Murphy

Controls:
Left Mouse Button(hold) - Unlock camera rotation
Mouse Move - Camera Rotation;
W,A,S,D - Camera Movement
Left Shift(hold) - Camera Speed X 10

Up/Down Arrow - Increase/Decrease Music Volume
Right/Left Arrow - Increase/Decrease Audio World Scale
Space - Spawn explosion sound at origin

1 - Play Music Loop
2 - Stop Music Loop
3 - Spawn 3D Sound with no params (plays directly on the listener)

Escape - Exit Application

Description:
This is a simple application demonstrating the basic use/functionality of the wwise sdk for audio. 
There are two multi colored blocks, one rotating at the origin, and a smaller one Orbiting the origin. 
The Orbiting Cube is emmitting a looping 3D Car Sound. Try rotating and moving the camera around to really emphasize the 3D sound.
