//--------------------------------------------------------------------------------
// Written by Justin Murphy
//--------------------------------------------------------------------------------
#include "./Renderer.h"
#include "./FileLoader.h"
#include "./DXLog.h"
#include "./Texture2d.h"
#include "./ExporterHeader.h"
//--------------------------------------------------------------------------------
//include the needed libraries for rendering
#pragma comment(lib,"d3d11.lib")
#pragma comment (lib, "DXGI.lib")
#pragma comment(lib,"winmm.lib")
#pragma comment(lib,"comctl32.lib")

//--------------------------------------------------------------------------------

bool windowed = false;
//--------------------------------------------------------------------------------
D3D_DRIVER_TYPE         g_driverType = D3D_DRIVER_TYPE_NULL;
D3D_FEATURE_LEVEL       g_featureLevel = D3D_FEATURE_LEVEL_11_0;
ID3D11Device*           g_pd3dDevice = nullptr;
ID3D11DeviceContext*    g_pImmediateContext = nullptr;
IDXGISwapChain*         g_pSwapChain = nullptr;
ID3D11Buffer*           g_pConstantBuffer = nullptr;
IDXGIOutput *			m_pVideoOutput = nullptr;
Texture2D *				m_backBuffer = nullptr;
Depth2D *				m_depth = nullptr;
std::vector<DXGI_MODE_DESC> pDescs;

//--------------------------------------------------------------------------------
bool Renderer::FindAdapter(IDXGIFactory1 **_factory, IDXGIAdapter1 **_adapter) {
	HRESULT hr = S_OK;
	IDXGIAdapter1 * pCurrentAdapter = nullptr;
	DXGI_ADAPTER_DESC1 Bestdesc;

	// Create a factory to enumerate all of the hardware in the system.
	DXCall(hr = CreateDXGIFactory1(__uuidof(IDXGIFactory), reinterpret_cast<void**>(_factory) ) );

	if (!*_factory) {
		Log("Could not create the factory");
		return false;
	}
	unsigned int index = 0;
	while (DXGI_ERROR_NOT_FOUND != (*_factory)->EnumAdapters1(index++, &pCurrentAdapter)) {
		DXGI_ADAPTER_DESC1 desc;
		ZeroMemory(&desc, sizeof(desc) );
		DXCall(pCurrentAdapter->GetDesc1(&desc));
		if (nullptr == *_adapter) {
			*_adapter = pCurrentAdapter;
			Bestdesc = desc;
		}
		else if (Bestdesc.DedicatedSystemMemory < desc.DedicatedSystemMemory) {
			(*_adapter)->Release();
			*_adapter = pCurrentAdapter;
			Bestdesc = desc;
		}
		else {
			pCurrentAdapter->Release();
		}
	}
	return true;
}
//--------------------------------------------------------------------------------
void Renderer::GetModeDesc(DXGI_MODE_DESC &_config) {
	UINT num = 0;
	DXGI_FORMAT format = DXGI_FORMAT_R8G8B8A8_UNORM_SRGB;
	UINT flags = DXGI_ENUM_MODES_INTERLACED;
	if (windowed)
		_config.Scaling = DXGI_MODE_SCALING_STRETCHED;
	else
		_config.Scaling = DXGI_MODE_SCALING_UNSPECIFIED;

	DXCall(m_pVideoOutput->GetDisplayModeList(format, flags, &num, 0));
	if (0 < num) {
		pDescs.resize(num);
		DXCall(m_pVideoOutput->GetDisplayModeList(format, flags, &num, &pDescs[0]));
		int poop = 0;
		bool found = false;
		for (unsigned int i = 0; i < num; ++i) {
			if (_config.Format == pDescs[i].Format &&
				_config.Height == pDescs[i].Height &&
				_config.Width == pDescs[i].Width) {
				found = true;
			}
		}

		if (false == found) {
			DXGI_MODE_DESC startDesc = _config;
			DXCall(m_pVideoOutput->FindClosestMatchingMode(&startDesc, &_config, g_pd3dDevice) );
		}
	}
}
//--------------------------------------------------------------------------------
void Renderer::SetModeDesc(DXGI_MODE_DESC &_config) {
	if (pDescs[pDescs.size() - 1].Width != _config.Width)
		_config.Scaling = DXGI_MODE_SCALING_STRETCHED;
	else
		_config.Scaling = DXGI_MODE_SCALING_UNSPECIFIED;

	DXGI_MODE_DESC startDesc = _config;
	DXCall(m_pVideoOutput->FindClosestMatchingMode(&startDesc, &_config, g_pd3dDevice) );
}
//--------------------------------------------------------------------------------
void Renderer::Resize(int _width, int _height) {
	if (nullptr == g_pSwapChain) {
		return;
	}
	HRESULT hr = E_FAIL;
	DXGI_SWAP_CHAIN_DESC config;
	
	g_pSwapChain->GetDesc(&config);

	config.BufferDesc.Width = _width;
	config.BufferDesc.Height = _height;
	config.BufferDesc.RefreshRate.Denominator = 0;
	config.BufferDesc.RefreshRate.Numerator = 0;
	SetModeDesc(config.BufferDesc);

	Log("ResizeBuffers ", windowed == true ? "Windowed " : "Full Screen ", "Width: ", config.BufferDesc.Width, " Height: ", config.BufferDesc.Height);
	if (m_backBuffer) {
		m_backBuffer->Release();
		delete m_backBuffer;
	}
	if (m_depth) {
		m_depth->Release();
		delete m_depth;
	}

	if (FAILED(hr = g_pSwapChain->ResizeBuffers(config.BufferCount, config.BufferDesc.Width, config.BufferDesc.Height, config.BufferDesc.Format, DXGI_SWAP_CHAIN_FLAG_ALLOW_MODE_SWITCH))) {
		DXMemoryCheck(2, g_pImmediateContext);
	}

	ID3D11Texture2D * pBackBuffer = nullptr;
	DXCall(g_pSwapChain->GetBuffer(0, __uuidof(ID3D11Texture2D), (LPVOID *)&pBackBuffer));
	m_backBuffer = new Texture2D(g_pd3dDevice, pBackBuffer, "Back Buffer");
	m_depth = new Depth2D(g_pd3dDevice, config.BufferDesc.Width, config.BufferDesc.Height, "DEPTH", D3D11_BIND_DEPTH_STENCIL | D3D11_BIND_SHADER_RESOURCE);
}
//--------------------------------------------------------------------------------
bool Renderer::Initialize() {
	HRESULT hr = S_OK;
	IDXGIFactory1 * factory = nullptr;
	IDXGIAdapter1 * adapter = nullptr;
	D3D_FEATURE_LEVEL CreatedLevel = D3D_FEATURE_LEVEL_11_1;

	EventManager()->RegisterClient("AddRenderNode", this, &Renderer::AddNodeRenderNode);
	
	if (!FindAdapter(&factory, &adapter)) {
		return false;
	}
	windowed = true;

	UINT createDeviceFlags = 0;
#ifdef _DEBUG
	createDeviceFlags |= D3D11_CREATE_DEVICE_DEBUG;
#endif

	D3D_FEATURE_LEVEL featureLevels[] = {
		D3D_FEATURE_LEVEL_11_0,
		D3D_FEATURE_LEVEL_10_1,
		D3D_FEATURE_LEVEL_10_0,
	};

	//If you set the pAdapter parameter to a non - NULL value, you must also set the DriverType parameter to the D3D_DRIVER_TYPE_UNKNOWN value.
	//If you set the pAdapter parameter to a non - NULL value and the DriverType parameter to the D3D_DRIVER_TYPE_HARDWARE value, 
	//D3D11CreateDevice returns an HRESULT of E_INVALIDARG.
	DXCall(hr = D3D11CreateDevice(adapter, D3D_DRIVER_TYPE_UNKNOWN, nullptr, createDeviceFlags,
		featureLevels, ARRAYSIZE(featureLevels), D3D11_SDK_VERSION,
		&g_pd3dDevice, &CreatedLevel,
		&g_pImmediateContext));

	if (SUCCEEDED(hr) ) {
		//Could loop and get all the outputs but I am unsure why I would do that right now
		DXCall(hr = adapter->EnumOutputs(0, &m_pVideoOutput));
	}
	if (FAILED(hr)) {
		Log("Could not create the device");
		return false;
	}

	DXNameInit(g_pImmediateContext);
	DXName(g_pd3dDevice, "My Device");
	DXName(g_pImmediateContext, "My Context");

	SAFE_RELEASE(adapter);
	SAFE_RELEASE(factory);

	Log("Created Device and Context Successfully");

	return true;
}
//--------------------------------------------------------------------------------
void Renderer::CreateSwapChain(int _width, int _hieght, HWND _hwnd) {
	DXGI_SWAP_CHAIN_DESC Config;
	Config.BufferDesc.Width = _width;
	Config.BufferDesc.Height = _hieght;
	Config.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM_SRGB;
	Config.BufferDesc.ScanlineOrdering = DXGI_MODE_SCANLINE_ORDER_UNSPECIFIED;
	Config.BufferDesc.Scaling = DXGI_MODE_SCALING_UNSPECIFIED;
	Config.BufferDesc.RefreshRate.Numerator = 0;
	Config.BufferDesc.RefreshRate.Denominator = 0;
	Config.SampleDesc.Count = 1;
	Config.SampleDesc.Quality = 0;
	Config.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
	Config.BufferCount = 2;
	Config.OutputWindow = _hwnd;
	Config.Windowed = windowed;
	Config.SwapEffect = DXGI_SWAP_EFFECT_DISCARD;
	Config.Flags = DXGI_SWAP_CHAIN_FLAG_ALLOW_MODE_SWITCH;

	HRESULT hr = E_FAIL;

	IDXGIDevice * pDXGIDevice = nullptr;
	DXCall(g_pd3dDevice->QueryInterface(__uuidof(IDXGIDevice *), reinterpret_cast<void**>(&pDXGIDevice)));

	IDXGIAdapter * pDXGIAdapter = nullptr;
	DXCall(pDXGIDevice->GetParent(__uuidof(IDXGIAdapter), reinterpret_cast<void **>(&pDXGIAdapter)));

	IDXGIFactory * pFactory = nullptr;
	DXCall(pDXGIAdapter->GetParent(__uuidof(IDXGIFactory), reinterpret_cast<void **>(&pFactory)));

		
	GetModeDesc(Config.BufferDesc);
	//this is changed sometimes
	Config.Flags = DXGI_SWAP_CHAIN_FLAG_ALLOW_MODE_SWITCH;

	//// Attempt to create the swap chain.
	DXCall(hr = pFactory->CreateSwapChain(g_pd3dDevice, &Config, &g_pSwapChain));
		
	if (FAILED(hr)) {
		Log("Failed to create swap chain!");
		SAFE_RELEASE(pFactory);
		SAFE_RELEASE(pDXGIAdapter);
		SAFE_RELEASE(pDXGIDevice);
		//return -1;
	}
	//We now have to do all the window and swap changes ourselves in wndproc
	//Better than all the possible errors that happen when it does it with the swap chain talking to the hwnd though wndproc
	//Reduces the number of messages sent as well
	DXCall(pFactory->MakeWindowAssociation(Config.OutputWindow, DXGI_MWA_NO_WINDOW_CHANGES | DXGI_MWA_NO_ALT_ENTER));

	DXName(g_pSwapChain, "SwapChain");
	windowed = Config.Windowed == 0 ? false : true;

	Resize(Config.BufferDesc.Width, Config.BufferDesc.Height);

	SAFE_RELEASE(pFactory);
	SAFE_RELEASE(pDXGIAdapter);
	SAFE_RELEASE(pDXGIDevice);

	// Setup the viewport
	D3D11_VIEWPORT vp;
	vp.Width = (FLOAT)Config.BufferDesc.Width;
	vp.Height = (FLOAT)Config.BufferDesc.Height;
	vp.MinDepth = 0.0f;
	vp.MaxDepth = 1.0f;
	vp.TopLeftX = 0;
	vp.TopLeftY = 0;
	g_pImmediateContext->RSSetViewports(1, &vp);

	Log("Created Swap Chain and Viewport Sucessfully");
	return;
}
//--------------------------------------------------------------------------------
void Renderer::CleanupDevice() {
	SAFE_RELEASE(m_pVideoOutput);
	if (nullptr != g_pSwapChain) {
		windowed = true;
		g_pSwapChain->SetFullscreenState(false, nullptr);
	}
	if (m_backBuffer) {
		m_backBuffer->Release();
		delete m_backBuffer;
	}
	if (m_depth) {
		m_depth->Release();
		delete m_depth;
	}
	unsigned int loopMax = m_VSShaders.size();
	unsigned int i = 0;

	for (i = 0; i < loopMax; ++i) {
		SAFE_RELEASE(m_VSShaders[i]);
	}
	m_VSShaders.clear();

	loopMax = m_buffers.size();
	for (i = 0; i < loopMax; ++i) {
		SAFE_RELEASE(m_buffers[i]);
	}
	m_buffers.clear();

	loopMax = m_PSShaders.size();
	for (i = 0; i < loopMax; ++i) {
		SAFE_RELEASE(m_PSShaders[i]);
	}
	m_PSShaders.clear();

	loopMax = m_Layouts.size();
	for (i = 0; i < loopMax; ++i) {
		SAFE_RELEASE(m_Layouts[i]);
	}
	m_Layouts.clear();

	SAFE_RELEASE(g_pConstantBuffer);
	//SAFE_RELEASE(g_pVertexBuffer);
	//SAFE_RELEASE(g_pIndexBuffer);
	//SAFE_RELEASE(g_pVertexLayout);

	//SAFE_RELEASE(g_pPixelShader);

	SAFE_RELEASE(g_pSwapChain);
	SAFE_RELEASE(g_pImmediateContext);
	//If the refence is not zero more information is printed out to the log
	if (g_pd3dDevice) {
		DXMemoryCheck(g_pd3dDevice->Release(), g_pImmediateContext);
	}

	DXDebugRelease();
}
//--------------------------------------------------------------------------------
void Renderer::RenderNodes() {
	BeginRender();
	//these are put here to group all the calls together
	//The DXDrawName stoped the grouping when it runs out of scope
	{
		DXDrawName("Draw Boxes");
		unsigned int numNodes = RenderList.size();
		for (unsigned int i = 0; i < numNodes; ++i) {
			m_buffer.mWorld = RenderList[i].GetData().mWorld;
			const PerType &info = RenderList[i].GetData().tRenderType;
			//No Context manager setting common settings for objects
			UINT stride = sizeof(SimpleVertex);
			UINT offset = 0;
			g_pImmediateContext->IASetInputLayout(m_Layouts[info.layout]);
			g_pImmediateContext->IASetVertexBuffers(0, 1, &m_buffers[info.vertexBuffer], &stride, &offset);
			g_pImmediateContext->IASetIndexBuffer(m_buffers[info.indexBuffer], static_cast<DXGI_FORMAT>(info.indexFormat), 0);
			
			g_pImmediateContext->VSSetShader(m_VSShaders[info.vs], NULL, 0);
			g_pImmediateContext->PSSetShader(m_PSShaders[info.ps], NULL, 0);

			g_pImmediateContext->UpdateSubresource(g_pConstantBuffer, 0, NULL, &m_buffer, 0, 0);
			g_pImmediateContext->DrawIndexed(36, 0, 0);
		}
	}
	Present();
	RenderList.clear();
}
//--------------------------------------------------------------------------------
void Renderer::BeginRender() {
	{
		DXDrawName(L"Clear the back buffer");
		// Clear the back buffer
		float ClearColor[4] = { 0.0f, 0.125f, 0.3f, 1.0f }; //red, green, blue, alpha
		g_pImmediateContext->ClearRenderTargetView(m_backBuffer->GetRenderTarget(), ClearColor);

		// Clear the depth buffer to 1.0 (max depth)
		g_pImmediateContext->ClearDepthStencilView(m_depth->GetDepthStencil(), D3D11_CLEAR_DEPTH, 1.0f, 0);
		g_pImmediateContext->OMSetRenderTargets(1, m_backBuffer->SetRenderTarget(), m_depth->GetDepthStencil());
	}
	// Set primitive topology
	g_pImmediateContext->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
	g_pImmediateContext->VSSetConstantBuffers(0, 1, &g_pConstantBuffer);
}
//--------------------------------------------------------------------------------
void Renderer::Present() {
	// Present our back buffer to our front buffer first parameter makes it use vsync
	g_pSwapChain->Present( 1, 0 );
}
//--------------------------------------------------------------------------------
bool Renderer::GetWindowed() {
	return windowed;
}
//--------------------------------------------------------------------------------
void Renderer::ResizeTarget(int _width, int _height) {

	DXGI_SWAP_CHAIN_DESC config;
	g_pSwapChain->GetDesc(&config);

	config.BufferDesc.Width = _width;
	config.BufferDesc.Height = _height;
	//Log("Resize Target ", windowed == false ? "Full Screen" : "Windowed", " w: ", config.BufferDesc.Width, " h: ", config.BufferDesc.Height);
	config.BufferDesc.RefreshRate.Denominator = 0;
	config.BufferDesc.RefreshRate.Numerator = 0;
	SetModeDesc(config.BufferDesc);
	DXCall(g_pSwapChain->ResizeTarget(&config.BufferDesc));
	D3D11_VIEWPORT vp;
	vp.Width = (FLOAT)_width;
	vp.Height = (FLOAT)_height;
	vp.MinDepth = 0.0f;
	vp.MaxDepth = 1.0f;
	vp.TopLeftX = 0;
	vp.TopLeftY = 0;
	g_pImmediateContext->RSSetViewports(1, &vp);
}
//--------------------------------------------------------------------------------
void Renderer::SetFullScreen(bool _fullScreen) {
	//Log("SetFullScreen ", _fullScreen == true ? "Full Screen" : "Windowed");
	if (nullptr == g_pSwapChain)
		return;
	DXCall(g_pSwapChain->SetFullscreenState(_fullScreen, _fullScreen == true ? m_pVideoOutput : nullptr));
}
//--------------------------------------------------------------------------------
void Renderer::SetWindowed(bool _windowed) { windowed = _windowed; }
//--------------------------------------------------------------------------------
void Renderer::Load(int _w, int _h) {
	HRESULT hr = S_OK;

	D3D11_BUFFER_DESC bd;
	ZeroMemory(&bd, sizeof(bd));
		
	// Create the constant buffer
	bd.Usage = D3D11_USAGE_DEFAULT;
	bd.ByteWidth = sizeof(ConstantBuffer);
	bd.BindFlags = D3D11_BIND_CONSTANT_BUFFER;
	bd.CPUAccessFlags = 0;
	
	DXCall(hr = g_pd3dDevice->CreateBuffer(&bd, NULL, &g_pConstantBuffer) );
	if (FAILED(hr) ) {
		Log("Failed creating ConstantBuffer");
		return;
	}
					
	DXName(g_pConstantBuffer, "World View Projection Buffer");
				
	Log("Renderer Node Info Initialized");
}
//--------------------------------------------------------------------------------
void Renderer::AddNodeObject(const RenderData<PerObject> * args) {
	RenderList.push_back(*args);
}
//--------------------------------------------------------------------------------
void Renderer::AddNodeFrame(const RenderData<PerFrame> *args) {
	const PerFrame frame = args->GetData();
	m_buffer.mProjection = frame.mProjection;
	m_buffer.mView = frame.mView;
}
//--------------------------------------------------------------------------------
void Renderer::AddNodeRenderNode(const CGeneralEventArgs<RenderNode *>& args) {
	switch (args.GetData()->GetType() ){
	case RenderNode::DataType::WOLRD: {
		AddNodeObject(static_cast<RenderData<PerObject>*>(args.GetData() ) );
	}break;
	case RenderNode::DataType::VIEWPROJECTION: {
		AddNodeFrame(static_cast<RenderData<PerFrame>*>(args.GetData()));

	}break;
	default:
		Log("Bad RendernodeType");
	};
}
//--------------------------------------------------------------------------------
void Renderer::SetRenderNode(RenderNode *_node, const char *_key) {
	switch (_node->GetType()){
		case RenderNode::DataType::WOLRD: {
			RenderData<PerObject> * Obj = static_cast<RenderData<PerObject>*>(_node);
			SetRenderNode(Obj, _key);
		}break;
		case RenderNode::DataType::VIEWPROJECTION: {
			//do nothing
		}break;
		default:
			Log("Bad RendernodeType");
	};
}
//--------------------------------------------------------------------------------
void Renderer::SetRenderNode(RenderData<PerObject> *_node, const char *_key) {
	NodeItr itr = NodeTemplate.find(_key);
	if (itr == NodeTemplate.end() ) {
		PerType *info = new PerType;
		NodeTemplate.insert(std::make_pair(_key, info) );
		LoadData(info, _key);
		memcpy(&(_node->GetData().tRenderType), info, sizeof(_node->GetData().tRenderType));
		return;
	}
	memcpy(&(_node->GetData().tRenderType), itr->second, sizeof(_node->GetData().tRenderType));
}
//--------------------------------------------------------------------------------
void Renderer::LoadData(PerType * _info, const char *_key) {
	//Hack should be passed in by application
	const char * path = "./Resources/";
	std::string fileName = path;
	std::vector<int8_t> data;

	fileName += "RenderObjects/";
	fileName += _key;
	fileName += ".txt";
	memset(_info, -1, sizeof(PerType) );

	if (false == ReadEntireFile(data, fileName.c_str() ) ) {
		return;
	}
	char * tok = nullptr;
	char *asset = strtok_s(reinterpret_cast<char *>(&data[0]), " \r\n", &tok);
	FileInfo::ExporterHeader header;
	unsigned int modelType = LoadModel(header, path, asset, _info->vertexBuffer, _info->indexBuffer, _info->indexFormat);
	_info->vertexSize = header.mesh.vertSize;
	asset = strtok_s(nullptr, " \r\n", &tok);
	_info->vs = LoadVertexShader(path, asset, modelType, _info->layout);
	asset = strtok_s(nullptr, " \r\n", &tok);
	_info->ps = LoadPixelShader(path, asset);
	int poop = 0;
}
//--------------------------------------------------------------------------------
unsigned int  Renderer::LoadPixelShader(const char *_path, const char * _file) {
	HRESULT hr = S_OK;
	std::string FileName = _path;
	std::vector<int8_t> data;
	unsigned int index = m_PSShaders.size();
	m_PSShaders.push_back(nullptr);

	FileName += "Shaders/";
	FileName += _file;
	FileName += ".cso";

	if (false == ReadEntireFile(data, FileName.c_str())) {
		return -1;
	}

	DXCall(hr = g_pd3dDevice->CreatePixelShader(&data[0], data.size(), 0, &m_PSShaders[index]));
	if (FAILED(hr)) {
		Log("Failed to create pixel shader from compiled shader object ", _file);
		return - 1;
	}
	DXName(m_PSShaders[index], "PosColorPS");
	return index;
}
//--------------------------------------------------------------------------------
unsigned int Renderer::LoadVertexShader(const char *_path, const char * _file, unsigned int _LayoutType, unsigned int &_layoutIndex) {
	HRESULT hr = S_OK;
	unsigned int index = m_VSShaders.size();
	std::string FileName = _path;
	std::vector<int8_t> data;

	m_VSShaders.push_back(nullptr);
	FileName += "Shaders/";
	FileName += _file;
	FileName += ".cso";
	
	if (false == ReadEntireFile(data, FileName.c_str() ) ) {
		return -1;
	}

	DXCall(hr = g_pd3dDevice->CreateVertexShader(&data[0], data.size(), 0, &m_VSShaders[index]));
	if (FAILED(hr)) {
		Log("Failed to create vertex shader from compiled shader object");
		return - 1;
	}

	FileName = _file;
	FileName += " VS";
	DXName(m_VSShaders[index], FileName.c_str() );

	switch (static_cast<FileInfo::MODEL_TYPES>(_LayoutType) ) {
	case FileInfo::MODEL_TYPES::COLOR: {
		_layoutIndex = m_Layouts.size();
		m_Layouts.push_back(nullptr);
		D3D11_INPUT_ELEMENT_DESC layout[] = {
			{ "POSITION", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, 0, D3D11_INPUT_PER_VERTEX_DATA, 0 },
			{ "COLOR", 0, DXGI_FORMAT_R32G32B32A32_FLOAT, 0, 12, D3D11_INPUT_PER_VERTEX_DATA, 0 },
		};

		DXCall(hr = g_pd3dDevice->CreateInputLayout(layout, ARRAYSIZE(layout), &data[0], data.size(), &m_Layouts[_layoutIndex]));
		// Create the input layout
		if (FAILED(hr) ) {
			Log("Failed creating input layer");

			return -1;
		}
		
		DXName(m_Layouts[_layoutIndex], "Color Pos Vertex Layout");
	}break;
	default:
		Log("Layout type not supported");
	}

	return index;
}
//--------------------------------------------------------------------------------
unsigned int Renderer::LoadModel(FileInfo::ExporterHeader &_header, const char *_path, const char * _file, unsigned int &_VBuffer, unsigned int &_IBuffer, unsigned int &_IFormat) {
	HRESULT hr = S_OK;
	D3D11_BUFFER_DESC bd;
	std::string fileName = _path;

	ZeroMemory(&bd, sizeof(bd));
	fileName += "Models/";
	fileName += _file;
	fileName += ".bin";
	///////////////////////////////////////////////////////////////////////////////
	//File IO
	///////////////////////////////////////////////////////////////////////////////
	FILE *file = nullptr;
	fopen_s(&file, fileName.c_str(), "rb");
	if (!file) {
		Log("Could not open model ", fileName);
		return -1;
	}
	//Read header
	fread(&_header, sizeof(FileInfo::ExporterHeader), 1, file);

	//Set up based on Header Information
	std::vector<int8_t> buffer(_header.mesh.vertSize * _header.mesh.numPoints);
	unsigned int indexSize = 0;

	switch (_header.mesh.index) {
	case FileInfo::INDEX_TYPES::INDEX16:
		indexSize = sizeof(short);
		_IFormat = DXGI_FORMAT_R16_UINT;
		break;
	case FileInfo::INDEX_TYPES::INDEX32:
		indexSize = sizeof(int);
		_IFormat = DXGI_FORMAT_R32_UINT;
		break;
	case FileInfo::INDEX_TYPES::TRI_STRIP:
		indexSize = 0;
		_IBuffer = -1;
		_IFormat = -1;
		break;
	default:
		_IFormat = -1;
		_IBuffer = -1;
		Log("index type not supported");
		return -1;
	};
	std::vector<int8_t> iBuffer(_header.mesh.numIndex * indexSize);

	//Finish reading the data
	fread(&buffer[0], sizeof(BYTE), buffer.size(), file);
	if (0 < indexSize) {
		fread(&iBuffer[0], sizeof(indexSize), iBuffer.size(), file);
	}
	fclose(file);
	///////////////////////////////////////////////////////////////////////////////

	//Set Up GFX info for renderer
	_VBuffer = m_buffers.size();
	m_buffers.push_back(nullptr);
	_IBuffer = m_buffers.size();
	m_buffers.push_back(nullptr);

#pragma region CREATE_VERTEX_BUFFER
	bd.Usage = D3D11_USAGE_DEFAULT;
	bd.ByteWidth = buffer.size();
	bd.BindFlags = D3D11_BIND_VERTEX_BUFFER;
	bd.CPUAccessFlags = 0;
	D3D11_SUBRESOURCE_DATA InitData;
	ZeroMemory(&InitData, sizeof(InitData));
	InitData.pSysMem = &buffer[0];
	DXCall(hr = g_pd3dDevice->CreateBuffer(&bd, &InitData, &m_buffers[_VBuffer]));
	if (FAILED(hr)) {
		Log("failed creating buffer SimpleVertex");
		return - 1;
	}
	fileName = _file;
	fileName += " Vertex Buffer";
	DXName(m_buffers[_VBuffer], fileName.c_str());
#pragma endregion //might want to add this to a function
#pragma region CREATE_INDEX_BUFFER
	if (0 < indexSize) {
		bd.Usage = D3D11_USAGE_DEFAULT;
		bd.ByteWidth = iBuffer.size();
		bd.BindFlags = D3D11_BIND_INDEX_BUFFER;
		bd.CPUAccessFlags = 0;
		InitData.pSysMem = &iBuffer[0];

		DXCall(hr = g_pd3dDevice->CreateBuffer(&bd, &InitData, &m_buffers[_IBuffer]) );
		if (FAILED(hr)) {
			Log("Failed crating index buffer");
			return -1;
		}
		fileName = _file;
		fileName += " Index Buffer";
		DXName(m_buffers[_IBuffer], fileName.c_str() );
	}
#pragma endregion //May want to make this a function.  Only if we need to do this

	return static_cast<unsigned int>(_header.mesh.modelType);
}
//--------------------------------------------------------------------------------
bool Renderer::ReadEntireFile(std::vector<int8_t> &_data, const char *_filename) {
	FILE *file = nullptr;
	fopen_s(&file, _filename, "rb");
	if (!file) {
		Log("Could not open file ", _filename);
		return false;
	}
	fseek(file, 0, SEEK_END);
	_data.resize(ftell(file) );
	fseek(file, 0, SEEK_SET);

	fread(&_data[0], 1, _data.size(), file);
	fclose(file);

	return true;
}
//--------------------------------------------------------------------------------