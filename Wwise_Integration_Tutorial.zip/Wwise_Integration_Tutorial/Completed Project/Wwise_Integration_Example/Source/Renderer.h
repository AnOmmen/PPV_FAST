//--------------------------------------------------------------------------------
// Renderer
// Written by Justin Murphy
// 
// Super basic rendering functionality wrapped in a namespace
// For tutorial purposes only - was insanely lazy and there is no
// good structure to this code
//--------------------------------------------------------------------------------
#ifndef Renderer_h
#define Renderer_h
//--------------------------------------------------------------------------------
//Cannot include D3D11 the application should not care
#include <directxmath.h>
#include <stdint.h>

#include "./EventManager.h"
#include "./RenderNode.h"
//--------------------------------------------------------------------------------
namespace FileInfo {
	struct ExporterHeader;
};
struct HWND__;
typedef struct HWND__ *HWND;
struct IDXGIFactory1;
struct IDXGIAdapter1;
struct DXGI_MODE_DESC;
struct ID3D11VertexShader;
struct ID3D11Buffer;
struct ID3D11PixelShader;
struct ID3D11InputLayout;
//--------------------------------------------------------------------------------
class Renderer {
public:
	struct SimpleVertex {
		DirectX::XMFLOAT3 Pos;
		DirectX::XMFLOAT4 Color;
	};

	struct ConstantBuffer {
		DirectX::XMFLOAT4X4 mWorld;
		DirectX::XMFLOAT4X4 mView;
		DirectX::XMFLOAT4X4 mProjection;
	};
	
	void AddNodeObject(const RenderData<PerObject> * args);
	void AddNodeFrame(const RenderData<PerFrame> *args);
	void AddNodeRenderNode(const CGeneralEventArgs<RenderNode *>& args);

	bool Initialize();
	void CreateSwapChain(int _width, int _hieght, HWND _hwnd);
	void CleanupDevice();

	bool GetWindowed();
	void ResizeTarget(int _width, int _height);
	void Resize(int _width = 0, int _height = 0);
	void SetFullScreen(bool _fullScreen);
	void SetWindowed(bool _windowed);
	void Load(int _w, int _h);
	void RenderNodes();
	void SetRenderNode(RenderNode *_node, const char *_key);
private:
	void SetRenderNode(RenderData<PerObject> *_node, const char *_key);
	void LoadData(PerType * _info, const char *_key);
	unsigned int LoadVertexShader(const char *_path, const char * _file, unsigned int _LayoutType, unsigned int &_layoutIndex);
	unsigned int LoadPixelShader(const char *_path, const char * _file);
	unsigned int LoadModel(FileInfo::ExporterHeader &_header, const char *_path, const char * _file, unsigned int &_VBuffer, unsigned int &_IBuffer, unsigned int &_IFormat);
	bool ReadEntireFile(std::vector<int8_t> &_data, const char *_filename);

	void BeginRender();
	void Present();

	bool FindAdapter(IDXGIFactory1 **_factory, IDXGIAdapter1 **_adapter);
	void GetModeDesc(DXGI_MODE_DESC &_config);
	void SetModeDesc(DXGI_MODE_DESC &_config);
	ConstantBuffer m_buffer;
	std::vector<RenderData<PerObject> > RenderList;
	std::map<std::string, PerType *> NodeTemplate;
	typedef std::map<std::string, PerType *>::iterator NodeItr;

	std::vector<ID3D11VertexShader*> m_VSShaders;
	std::vector<ID3D11Buffer*> m_buffers;
	std::vector<ID3D11PixelShader*> m_PSShaders;
	std::vector<ID3D11InputLayout*> m_Layouts;
};
//--------------------------------------------------------------------------------
#endif // Renderer_h
//--------------------------------------------------------------------------------