#pragma once
//--------------------------------------------------------------------------------
#include <map>
#include <vector>

#include "RenderNode.h"
//--------------------------------------------------------------------------------
struct __declspec(novtable) BaseObject;
//--------------------------------------------------------------------------------
class ObjectRegistry {
public:
	typedef BaseObject* (*ObjectCreator)(void);
	typedef RenderNode * (*RenderNodeCreator)();

	template<typename T>
	friend BaseObject* objCreator(void){ return new T; }

	template<typename T>
	friend RenderNode* nodeCreator(void){ return new RenderData<T>; }

	template<typename T>
	unsigned int RegisterType(const char* identifier) {

		unsigned int result = RegisterType(identifier, &objCreator<T>);

		return result;
	}
	template<typename T>
	unsigned int RegisterRenderType(const char* identifier) {

		unsigned int result = RegisterNode(identifier, &nodeCreator<T>);

		return result;
	}
	BaseObject *CreateObject(const char *_key);
	RenderNode *CreateNode(const char *_key);
	void Update(float _DeltaTime);
	void DestroyObjects();
protected:
	unsigned int RegisterType(const char* identifier, ObjectCreator creator);
	unsigned int RegisterNode(const char* identifier, RenderNodeCreator creator);
private:
	std::vector<BaseObject *> Objects;
	std::vector<RenderNode *> Nodes;
	std::map<unsigned int, ObjectCreator> creatorMap;
	std::map<unsigned int, RenderNodeCreator> NodeMap;
	std::map<unsigned int, std::string> stringMap;
	typedef std::map<unsigned int, ObjectCreator>::iterator objItr;
	typedef std::map<unsigned int, RenderNodeCreator>::iterator nodeItr;
};
//--------------------------------------------------------------------------------