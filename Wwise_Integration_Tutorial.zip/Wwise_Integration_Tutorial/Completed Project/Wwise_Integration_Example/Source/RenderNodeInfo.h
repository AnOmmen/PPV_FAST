#pragma once
#include <DirectXMath.h>

struct PerLocation {
	DirectX::XMFLOAT4X4 mWorld;
};
struct PerType {
	unsigned int vs;
	unsigned int ps;
	unsigned int layout;
	unsigned int vertexBuffer;
	unsigned int vertexSize;
	unsigned int indexBuffer;
	unsigned int indexFormat;
};
struct PerObject :public PerLocation{
	PerType tRenderType;
};
struct PerFrame :public PerLocation {
	DirectX::XMFLOAT4X4 mView;
	DirectX::XMFLOAT4X4 mProjection;
};
