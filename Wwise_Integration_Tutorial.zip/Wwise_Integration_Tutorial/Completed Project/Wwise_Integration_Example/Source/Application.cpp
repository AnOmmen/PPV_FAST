//--------------------------------------------------------------------------------
// Written by Justin Murphy
//--------------------------------------------------------------------------------
#include <ctime> // for seeding rand
//#include <vld.h>

#include "./Application.h"
#include "./MainWindow.h"
#include "./InputManager.h"
#include "./PrecisionTimer.h"
#include "./Log.h"
#include "./EventManager.h"
#include "./Renderer.h"
#include "./InputManager.h"
#include "./ObjectRegistry.h"

//--------------------------------------------------------------------------------
CApplication* CApplication::s_pInstance = nullptr;
//--------------------------------------------------------------------------------
int APIENTRY WinMain(_In_ HINSTANCE hInstance,
	_In_opt_ HINSTANCE hPrevInstance,
	_In_ LPSTR lpCmdLine,// -debug
	_In_ int nShowCmd) {
	UNREFERENCED_PARAMETER(hInstance);
	UNREFERENCED_PARAMETER(hPrevInstance);
	UNREFERENCED_PARAMETER(lpCmdLine);
	UNREFERENCED_PARAMETER(nShowCmd);

	LogSetUp(L"MurphyGaming Tutorial Series WWise");

	//Seed rand
	srand((unsigned)time(0) );
	CApplication* pApp = nullptr;

	// Initialize Event System
	CEventManager::CreateInstance();
	pApp = CreateApplication();

	if (!pApp->Init() ) {
		return 1;
	}
	pApp->SceneInit();
	pApp->Run();

	pApp->SceneEnd();

	delete pApp;

	EventManager()->Shutdown();
	CEventManager::DestroyInstance();
	
	LogShutDown();

	return 0;
}
//--------------------------------------------------------------------------------
CApplication::CApplication() :
	m_szWindowTitle(L"Default window name"),
	m_nWindowWidth(800),
	m_nWindowHeight(600),
	m_bIsActive(true) {
	if( s_pInstance ) {
		Log("Will Not open Application already running");
		return;//throw CError("Application object already created!\n");
	}
	s_pInstance = this;
}
//--------------------------------------------------------------------------------
CApplication::~CApplication() {
	CInputManager::DestroyInstance();
	delete m_window;
	m_window = nullptr;
	delete m_dxRender;
	m_dxRender = nullptr;
	delete m_Objects;
	m_Objects = nullptr;
}
//--------------------------------------------------------------------------------
bool CApplication::Init() {
	m_dxRender = new Renderer;
	if (false == m_dxRender->Initialize())
		return false;
	CInputManager::CreateInstance();

	m_window = new CMainWindow(m_nWindowWidth, m_nWindowHeight, m_szWindowTitle);

	m_window->Initialize(this);
	m_window->SetWindowed(true);
	m_window->SetSize(1024, 768);
	m_dxRender->CreateSwapChain(m_window->GetMaxWidth(), m_window->GetMaxHieght(), m_window->GetHWnd());
	m_dxRender->Load(m_window->GetMaxWidth(), m_window->GetMaxHieght());

	m_Objects = new ObjectRegistry;
	return true;
}
//--------------------------------------------------------------------------------
void CApplication::Run() {
	CPrecisionTimer::Init();
	while( true ) {
		// Message pump
		while (m_window->HasMessages()) {
			if (false == m_window->MessagePump())
				return;
		}

		CPrecisionTimer::GlobalUpdate();
		if( m_bIsActive  ) {
			float fdt = CPrecisionTimer::GetDeltaTime();
			static float totalTime = 0;
			totalTime += fdt;
			DoFrame(fdt, totalTime );

			// Update the Input devices after doing frame so the keys will buffer properly
			InputManager()->UpdateKeyStates(CPrecisionTimer::GetDeltaTime() );
		}
		else {
			float fdt = CPrecisionTimer::GetDeltaTime();
			static float totalTime = 0;
			totalTime += fdt;
			DoIdleFrame(fdt, totalTime );
		}
	}
}
//--------------------------------------------------------------------------------
void CApplication::DoFrame( float timeDelta, float timeTotal ) {
	m_Objects->Update(timeDelta);
	m_dxRender->RenderNodes();
}
//--------------------------------------------------------------------------------
void CApplication::DoIdleFrame( float timeDelta, float timeTotal ) {}
//--------------------------------------------------------------------------------
LRESULT CApplication::WindowProc(HWND _hWnd, UINT _msg, WPARAM _wParam, LPARAM _lParam) {
	bool bNoInput = InputManager()->HandleWindowMessages(_msg, _wParam, _lParam);
	switch (_msg) {
		case WM_NCACTIVATE: {
			if (0 == _wParam && 0 != m_window->GetHWnd()) {
				if (m_dxRender->GetWindowed() == false) {
					m_window->SetWindowed(false);
				}
			}
		} break;
		case WM_SETFOCUS: {
			if (m_dxRender->GetWindowed() == false) {
				m_dxRender->ResizeTarget(m_window->GetWindowWidth(), m_window->GetWindowHeight());
				m_dxRender->SetFullScreen(true);
			}
		} break;
		//to remove the beep from alt tabbing from fullscreen to windowed
		case WM_SYSCOMMAND: {
			switch (_wParam) {
			case SC_KEYMENU:{
				return 1;
			}
			};
		} break;
		//Debug keys for changing resolution //TODO take out
		case WM_KEYDOWN:{
			//char t = _wParam;
			//switch (t) {
			//	case 'W': {
			//		//Log("Litte Change resolution");
			//		m_window->ResizeWindow(1024, 768);
			//		m_renderer->ResizeTarget(m_window->GetTrueWidth(), m_window->GetTrueHeight());
			//	} break;
			//	case 'Q': {
			//		//Log("Med Change resolution");
			//		m_window->ResizeWindow(1280, 720);
			//		m_renderer->ResizeTarget(m_window->GetTrueWidth(), m_window->GetTrueHeight());
			//	} break;
			//	case 'E': {
			//		//Log("Big Change resolution");
			//		m_window->ResizeWindow(1920, 1080);
			//		m_renderer->ResizeTarget(m_window->GetTrueWidth(), m_window->GetTrueHeight());
			//	} break;
			//}
		}break;
		case WM_SYSKEYDOWN:{
			switch (_wParam) {
			case VK_RETURN: {
				if ((_lParam & (1 << 29)) != 0) {
					m_dxRender->SetWindowed(!m_dxRender->GetWindowed());
					m_dxRender->ResizeTarget(m_window->GetWindowWidth(), m_window->GetWindowHeight());
					m_dxRender->SetFullScreen(!m_dxRender->GetWindowed());
				}
			}break;
			};
		} break;
		case WM_SIZE: {
			m_window->DebugFlags();
			m_window->SetSize(m_window->GetWindowWidth(), m_window->GetWindowHeight());
			m_dxRender->Resize(m_window->GetWindowWidth(), m_window->GetWindowHeight());
		} break;
			// This message is sent when a window has been destroyed.
		case WM_DESTROY: {
			PostQuitMessage(0);
			return(0);
		} break;
	};

	return DefWindowProc(_hWnd, _msg, _wParam, _lParam);
}
//--------------------------------------------------------------------------------
void CApplication::SceneInit() {}
//--------------------------------------------------------------------------------
void CApplication::SceneEnd() {
	m_dxRender->CleanupDevice();
	m_Objects->DestroyObjects();
}
//--------------------------------------------------------------------------------
BaseObject *CApplication::CreateObject(const char *_key) {
	return m_Objects->CreateObject(_key);
}
//--------------------------------------------------------------------------------
RenderNode *CApplication::CreateRenderNode(const char *_key) {
	RenderNode *Node = m_Objects->CreateNode(_key);
	m_dxRender->SetRenderNode(Node, _key);
	return Node;
}
