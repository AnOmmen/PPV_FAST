//--------------------------------------------------------------------------------
// Written by Justin Murphy
//--------------------------------------------------------------------------------
#include "Entity3D.h"
#include "Log.h"
#include "RenderNode.h"

using namespace DirectX;
//--------------------------------------------------------------------------------
Entity3D::Entity3D() : type(UpdateTypes::ROTATE), totalTime(0.f) {
	func[static_cast<unsigned int>(UpdateTypes::ROTATE)] = &Entity3D::UpdateRotate;
	func[static_cast<unsigned int>(UpdateTypes::SPIN)] = &Entity3D::UpdateSpin;
}
//--------------------------------------------------------------------------------
bool Entity3D::SetUpdateType(UpdateTypes _type) {
	if (_type < UpdateTypes::NUM_UPDATE_TYPES) {
		type = _type;
		return true;
	}
	Log("Could not set update Type, invalid argument");
	return false;
}
//--------------------------------------------------------------------------------
void Entity3D::UpdateSpin(const float fDeltaTime) {
	XMMATRIX mSpin = XMMatrixRotationZ(-totalTime);
	XMMATRIX mOrbit = XMMatrixRotationY(-totalTime * 2.0f);
	XMMATRIX mTranslate = XMMatrixTranslation(-4.0f, 0.0f, 0.0f);
	XMMATRIX mScale = XMMatrixScaling(0.3f, 0.3f, 0.3f);
	//the matrix *= operator adds an addition pointer dereference.  Below is better than calling ... World = mScale * mSpin * mTranslate * mOrbit;
	XMMATRIX World = XMMatrixMultiply(XMMatrixMultiply(XMMatrixMultiply(mScale, mSpin), mTranslate), mOrbit);
	XMFLOAT4X4 newLocal;
	//store the entities new location
	XMStoreFloat4x4(&newLocal, World);
	m_location.SetLocalMatrix(newLocal);
}
//--------------------------------------------------------------------------------
void Entity3D::UpdateRotate(const float fDeltaTime) {
	XMFLOAT4X4 newLocal;
	//store the entities new location
	XMStoreFloat4x4(&newLocal, XMMatrixMultiply(XMMatrixRotationY(totalTime), XMMatrixTranslation(0.f, 0.f, 0.5f * totalTime) ) );
	m_location.SetLocalMatrix(newLocal);
}
//--------------------------------------------------------------------------------
Entity3D::~Entity3D() { }
//--------------------------------------------------------------------------------
void Entity3D::DestroyObject() {
	if (callback) {
		callback(this);
	}
}
//--------------------------------------------------------------------------------
void Entity3D::SetPosition(const XMFLOAT3 pos) {
	XMFLOAT4X4 newLocal = m_location.GetLocalMatrix();
	newLocal._41 = pos.x;
	newLocal._42 = pos.y;
	newLocal._43 = pos.z;
	m_location.SetLocalMatrix(newLocal);
}
//--------------------------------------------------------------------------------
void Entity3D::SetXAxis(const XMFLOAT3 xAxis) {
	XMFLOAT4X4 newLocal = m_location.GetLocalMatrix();
	newLocal._11 = xAxis.x;
	newLocal._12 = xAxis.y;
	newLocal._13 = xAxis.z;
	m_location.SetLocalMatrix(newLocal);
}
//--------------------------------------------------------------------------------
void Entity3D::SetYAxis(const XMFLOAT3 yAxis) {
	XMFLOAT4X4 newLocal = m_location.GetLocalMatrix();
	newLocal._21 = yAxis.x;
	newLocal._22 = yAxis.y;
	newLocal._23 = yAxis.z;
	m_location.SetLocalMatrix(newLocal);
}
//--------------------------------------------------------------------------------
void Entity3D::SetZAxis(const XMFLOAT3 zAxis) {
	XMFLOAT4X4 newLocal = m_location.GetLocalMatrix();
	newLocal._31 = zAxis.x;
	newLocal._32 = zAxis.y;
	newLocal._33 = zAxis.z;
	m_location.SetLocalMatrix(newLocal);
}
//--------------------------------------------------------------------------------
void Entity3D::Update(const float fDeltaTime) {
	totalTime += fDeltaTime;
	(this->*func[static_cast<unsigned int>(type)])(fDeltaTime);
	UpdateRenderNode();
}
//--------------------------------------------------------------------------------
void Entity3D::UpdateRenderNode() {
	PerObject data;
	data.mWorld = m_location.GetWorldMatrix();

	static_cast<RenderData<PerObject>*>(m_renderNode)->SetData(data);

	super::UpdateRenderNode();
}
//--------------------------------------------------------------------------------