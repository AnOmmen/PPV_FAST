//--------------------------------------------------------------------------------
// Written by Justin Murphy
//--------------------------------------------------------------------------------
#include "Game.h"
#include "InputManager.h"
#include "MainWindow.h"
#include "Renderer.h"
#include "Wwise_IDs.h"
#include "Camera.h"
#include "EventManager.h"
#include "Log.h"
//--------------------------------------------------------------------------------
bool CGame::m_bShowCursor = true;
bool CGame::m_bKeepCursorPos = true;
//--------------------------------------------------------------------------------
CGame::CGame() : 
	CApplication(), 
	volume(50.f), 
	AudioScaling(1.f) {
	m_szWindowTitle = L"Murphy Wwise Integration Tutorial";
	m_nWindowWidth = 1280;
	m_nWindowHeight = 800;
}
//--------------------------------------------------------------------------------
void CGame::SceneInit() {
	// initialize DX
	if(FAILED(Renderer::InitDevice(MainWindow()->GetHWnd() ) ) ) {
		PostQuitMessage(-1);
	}

	//Sound Inputs
	EventManager()->RegisterClient(InputManager()->BindKeyDownEvent(VK_UP, "VolumeUp"), this, &CGame::VolumeUp);
	EventManager()->RegisterClient(InputManager()->BindKeyDownEvent(VK_DOWN, "VolumeDown"), this, &CGame::VolumeDown);
	EventManager()->RegisterClient(InputManager()->BindKeyDownEvent(VK_RIGHT, "IncreaseWorldScale"), this, &CGame::WorldScaleUp);
	EventManager()->RegisterClient(InputManager()->BindKeyDownEvent(VK_LEFT, "DecreaseWorldScale"), this, &CGame::WorldScaleDown);
	EventManager()->RegisterClient(InputManager()->BindKeyPressEvent(VK_SPACE, "3DSound"), this, &CGame::Play3DSound);
	EventManager()->RegisterClient(InputManager()->BindKeyPressEvent('1', "PlayMusic"), this, &CGame::PlayMusic);
	EventManager()->RegisterClient(InputManager()->BindKeyPressEvent('2', "StopMusic"), this, &CGame::StopMusic);
	EventManager()->RegisterClient(InputManager()->BindKeyPressEvent(VK_ESCAPE, "QUIT"), this, &CGame::StopGame);

	//Input first frame down
	EventManager()->RegisterClient(InputManager()->BindKeyPressEvent('3', "3DSound_NoParam"), this, &CGame::Play3DSoundNoParam);
	
    // Initialize the view
	m_pCamera = new Camera();
	m_pCamera->LookAt(DirectX::XMFLOAT3(0.0f, 1.0f, -5.0f), DirectX::XMFLOAT3(0.0f, 1.0f, 0.0f), DirectX::XMFLOAT3(0.0f, 1.0f, 0.0f));
	m_pCamera->SetLens(DirectX::XM_PIDIV2, MainWindow()->GetWindowWidth()/(FLOAT)MainWindow()->GetWindowHeight(), 0.01f, 100.0f );

	// Initialize the audio system and start playing some looping sounds
	g_AudioSystem.Initialize();
	g_AudioSystem.SetBasePath( L"./Resources/SoundBanks/" );
	g_AudioSystem.LoadSoundBank(L"Init.bnk");
	g_AudioSystem.LoadSoundBank(L"SoundBank.bnk");
	g_AudioSystem.RegisterListener(m_pCamera,"Main Camera");
	g_AudioSystem.RegisterEntity(&m_Entity2, "Main Entity");
	g_AudioSystem.PostEvent(AK::EVENTS::PLAY_MX_MUSICLOOP_01);
	g_AudioSystem.PostEvent(AK::EVENTS::PLAY_FX_3D_CAR_LOOP,&m_Entity2);
}
//--------------------------------------------------------------------------------
void CGame::Update( float timeDelta, float totalTime ) {
	using namespace DirectX;
	// update the camera
	m_pCamera->Update(timeDelta);

	// 1st Cube: 
	//Rotate on the Y axis at the origin
	XMMATRIX World = XMMatrixRotationY(totalTime);
	XMStoreFloat4x4(&m_Entity1.m_mWorld, World);

	// 2nd Cube:
	//Orbit around origin
	XMMATRIX mSpin = XMMatrixRotationZ(-totalTime);
	XMMATRIX mOrbit = XMMatrixRotationY(-totalTime * 2.0f);
	XMMATRIX mTranslate = XMMatrixTranslation(-4.0f, 0.0f, 0.0f);
	XMMATRIX mScale = XMMatrixScaling(0.3f, 0.3f, 0.3f);
	//the matrix *= operator adds an addition pointer dereference.  Below is better than calling ... World = mScale * mSpin * mTranslate * mOrbit;
	World = XMMatrixMultiply(XMMatrixMultiply(XMMatrixMultiply(mScale, mSpin), mTranslate), mOrbit);
	

	//store the entities new location
	XMStoreFloat4x4(&m_Entity2.m_mWorld, World);


	g_AudioSystem.Update();
}
//--------------------------------------------------------------------------------
void CGame::Render()
{
	Renderer::BeginRender();
	Renderer::RenderCube(&m_Entity1,m_pCamera);
	Renderer::RenderCube(&m_Entity2,m_pCamera);
	Renderer::Present();
}
//--------------------------------------------------------------------------------
void CGame::VolumeUp(const CGeneralEventArgs<float>& args) {
	if (volume < 100.f)
		volume += .1f;
	g_AudioSystem.SetRTCPValue(AK::GAME_PARAMETERS::MX_VOLUME, volume);
}
//--------------------------------------------------------------------------------
void CGame::VolumeDown(const CGeneralEventArgs<float>& args) {
	if (volume > 0.f)
		volume -= .1f;
	g_AudioSystem.SetRTCPValue(AK::GAME_PARAMETERS::MX_VOLUME, volume);
}
//--------------------------------------------------------------------------------
void CGame::WorldScaleUp(const CGeneralEventArgs<float>& args) {
	if (AudioScaling < 100.f)
		AudioScaling += 0.1f;
	g_AudioSystem.SetWorldScale(AudioScaling);
}
//--------------------------------------------------------------------------------
void CGame::WorldScaleDown(const CGeneralEventArgs<float>& args) {
	if (AudioScaling > 0.f)
		AudioScaling -= 0.1f;
	g_AudioSystem.SetWorldScale(AudioScaling);
}
//--------------------------------------------------------------------------------
void CGame::Play3DSound(const CGeneralEventArgs<float>& args) {
	//post a 3D sound event at specific location
	g_AudioSystem.PostEvent(AK::EVENTS::PLAY_FX_3D_EXPLOSION, XMFLOAT3(0, 0, 0) );
}
//--------------------------------------------------------------------------------
void CGame::Play3DSoundNoParam(const CGeneralEventArgs<float>& args) {
	g_AudioSystem.PostEvent(AK::EVENTS::PLAY_FX_3D_EXPLOSION);
}
//--------------------------------------------------------------------------------
void CGame::PlayMusic(const CGeneralEventArgs<float>& args) {
	g_AudioSystem.PostEvent(AK::EVENTS::PLAY_MX_MUSICLOOP_01);
}
//--------------------------------------------------------------------------------
void CGame::StopMusic(const CGeneralEventArgs<float>& args) {
	g_AudioSystem.PostEvent(AK::EVENTS::STOP_MX_MUSICLOOP_01);
}
//--------------------------------------------------------------------------------
void CGame::StopGame(const CGeneralEventArgs<float>& args) {
	PostQuitMessage(0);
}
//--------------------------------------------------------------------------------
void CGame::SceneEnd() {

	g_AudioSystem.UnloadSoundBank(L"Init.bnk");
	g_AudioSystem.UnloadSoundBank(L"SoundBank.bnk");
	g_AudioSystem.UnRegisterListener(m_pCamera);
	g_AudioSystem.UnRegisterEntity(&m_Entity2);

	if(m_pCamera)
	{
		delete m_pCamera;
		m_pCamera = nullptr;
	}
	g_AudioSystem.Shutdown();
	Renderer::CleanupDevice();
}
//--------------------------------------------------------------------------------
void CGame::Pause() { 
	m_bIsActive = false;
	Show_Cursor();
#ifndef _DEBUG
	if(g_AudioSystem.GetInitialized() )
		g_AudioSystem.PostEvent(AK::EVENTS::PAUSE_ALL);
#endif
}
//--------------------------------------------------------------------------------
void CGame::UnPause() {
	m_bIsActive = true;
#ifndef _DEBUG
	if(g_AudioSystem.GetInitialized() )
		g_AudioSystem.PostEvent(AK::EVENTS::RESUME_ALL);
#endif
}
//--------------------------------------------------------------------------------
void CGame::DoFrame(float fDeltaTime, float totalTime) {
	EventManager()->ProcessEvents();
	Update(fDeltaTime,totalTime);
	Render();
}
//--------------------------------------------------------------------------------
void CGame::DoIdleFrame( float timeDelta, float totalTime ) {
	// for debugging continue to run and update the game
#ifdef _DEBUG
	Update(timeDelta,totalTime);
#else
	g_AudioSystem.Update();
#endif
}
//--------------------------------------------------------------------------------
CApplication* CreateApplication() {	return new CGame(); }
//--------------------------------------------------------------------------------
CGame::~CGame() {
	EventManager()->UnregisterClient("VolumeUp", this, &CGame::VolumeUp);
	EventManager()->UnregisterClient("VolumeDown", this, &CGame::VolumeDown);
	EventManager()->UnregisterClient("IncreaseWorldScale", this, &CGame::WorldScaleUp);
	EventManager()->UnregisterClient("DecreaseWorldScale", this, &CGame::WorldScaleDown);
	EventManager()->UnregisterClient("3DSound", this, &CGame::Play3DSound);
	EventManager()->UnregisterClient("StopMusic", this, &CGame::Play3DSoundNoParam);
	EventManager()->UnregisterClient("PlayMusic", this, &CGame::PlayMusic);
	EventManager()->UnregisterClient("StopMusic", this, &CGame::StopMusic);
	EventManager()->UnregisterClient("QUIT", this, &CGame::StopGame);

	InputManager()->DeActivateKey(VK_UP);
	InputManager()->DeActivateKey(VK_DOWN);
	InputManager()->DeActivateKey(VK_RIGHT);
	InputManager()->DeActivateKey(VK_LEFT);
	InputManager()->DeActivateKey(VK_SPACE);
	InputManager()->DeActivateKey('1');
	InputManager()->DeActivateKey('2');
	InputManager()->DeActivateKey('3');
	InputManager()->DeActivateKey(VK_ESCAPE);
}
//--------------------------------------------------------------------------------
void CGame::Show_Cursor() {
	if(!m_bShowCursor) {
		ShowCursor(true);
		m_bShowCursor = true;
		if(m_bKeepCursorPos)
			SetCursorPos(m_InitialCursorPos.x,m_InitialCursorPos.y);
	}
}
//--------------------------------------------------------------------------------
void CGame::Hide_Cursor() {
	if(m_bShowCursor) {
		ShowCursor(false);
		m_bShowCursor = false;
		if(m_bKeepCursorPos)
			GetCursorPos(&m_InitialCursorPos);
	}
}
//--------------------------------------------------------------------------------