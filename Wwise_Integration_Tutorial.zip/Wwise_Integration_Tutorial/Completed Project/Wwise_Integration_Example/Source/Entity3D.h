//--------------------------------------------------------------------------------
// Entity3D
// Written By: Justin Murphy
//
// very simple entity class holding a transform to represent 
// position and orientation of an object in 3D space
//--------------------------------------------------------------------------------
#ifndef Entity3D_h
#define Entity3D_h
//--------------------------------------------------------------------------------
#include <stdint.h>

#include "BaseObject.h"
#include "Delegate.h"
//--------------------------------------------------------------------------------
class Entity3D :public BaseObject {
	
public:
	enum class UpdateTypes : int8_t {ROTATE, SPIN, NUM_UPDATE_TYPES};
	Entity3D( );
	virtual ~Entity3D( );

	void Update(const float fDeltaTime) override;
	void DestroyObject() override;
	 
	const DirectX::XMFLOAT3 * GetPosition() const;
	const DirectX::XMFLOAT3 * GetYAxis() const;
	const DirectX::XMFLOAT3 * GetZAxis() const;

	void SetPosition(const DirectX::XMFLOAT3 pos);
	void SetXAxis(const DirectX::XMFLOAT3 xAxis);
	void SetYAxis(const DirectX::XMFLOAT3 yAxis);
	void SetZAxis(const DirectX::XMFLOAT3 zAxis);
	bool SetUpdateType(UpdateTypes _type);
	void UpdateRenderNode() override;

	template <class ObjectType, void (ObjectType::*_function)(Entity3D *)> 
	void SetCallback(ObjectType *_obj) {
		callback = Delegate<void, Entity3D *>::init<ObjectType, _function>(_obj);
	}
protected:
	typedef BaseObject super;
private:
	
	float totalTime;
	typedef void(Entity3D::*UpdateFuncs)(const float fDeltaTime);
	void UpdateSpin(const float fDeltaTime);
	void UpdateRotate(const float fDeltaTime);

	UpdateTypes type;
	UpdateFuncs func[static_cast<unsigned int>(UpdateTypes::NUM_UPDATE_TYPES)];
	Delegate<void, Entity3D *> callback;
};
//--------------------------------------------------------------------------------
#include "Entity3D.hpp"
//--------------------------------------------------------------------------------
#endif // Entity3D_h
//--------------------------------------------------------------------------------