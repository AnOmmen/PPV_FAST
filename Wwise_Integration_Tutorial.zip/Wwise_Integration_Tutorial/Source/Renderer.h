//--------------------------------------------------------------------------------
// Renderer
// Written by Justin Murphy
// 
// Super basic rendering functionality wrapped in a namespace
// For tutorial purposes only - was insanely lazy and there is no
// good structure to this code
//--------------------------------------------------------------------------------
#ifndef Renderer_h
#define Renderer_h
//--------------------------------------------------------------------------------
#include <d3d11.h>
#include <directxmath.h>
//--------------------------------------------------------------------------------
class Entity3D;
class Camera;
//--------------------------------------------------------------------------------
namespace Renderer {
	struct SimpleVertex {
		DirectX::XMFLOAT3 Pos;
		DirectX::XMFLOAT4 Color;
	};

	struct ConstantBuffer {
		DirectX::XMMATRIX mWorld;
		DirectX::XMMATRIX mView;
		DirectX::XMMATRIX mProjection;
	};
	
	HRESULT InitDevice(HWND hWnd);
	void CleanupDevice();
	void BeginRender();
	void RenderCube(const Entity3D* pObj,const Camera* pCamera);
	void Present();
};
//--------------------------------------------------------------------------------
#endif // Renderer_h
//--------------------------------------------------------------------------------