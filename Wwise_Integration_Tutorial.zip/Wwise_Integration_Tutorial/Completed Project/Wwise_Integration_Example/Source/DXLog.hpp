#pragma once
//--------------------------------------------------------------------------------
namespace COMBINE(Log, __ID__) {
#ifdef VISUAL_STUDIO_VISUAL_DEBUG_INFO
	void DXRelease();
#endif
};
//--------------------------------------------------------------------------------