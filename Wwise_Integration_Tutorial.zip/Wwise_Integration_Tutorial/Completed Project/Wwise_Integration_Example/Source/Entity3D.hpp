#pragma once
//--------------------------------------------------------------------------------
inline const DirectX::XMFLOAT3 * Entity3D::GetPosition() const { return reinterpret_cast<const DirectX::XMFLOAT3 *>(&const_cast<Transform *>(&m_location)->GetWorldMatrix()._41); }
//--------------------------------------------------------------------------------
inline const DirectX::XMFLOAT3 * Entity3D::GetYAxis() const { return reinterpret_cast<const DirectX::XMFLOAT3 *>(&const_cast<Transform *>(&m_location)->GetWorldMatrix()._21); }
//--------------------------------------------------------------------------------
inline const DirectX::XMFLOAT3 * Entity3D::GetZAxis() const { return reinterpret_cast<const DirectX::XMFLOAT3 *>(&const_cast<Transform *>(&m_location)->GetWorldMatrix()._31); }
//--------------------------------------------------------------------------------