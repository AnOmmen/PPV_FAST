#pragma once

//--------------------------------------------------------------------------------
inline const DirectX::XMFLOAT4X4 Camera::GetView() const { return m_mtxView; }
//--------------------------------------------------------------------------------
inline const DirectX::XMFLOAT4X4 Camera::GetProjection() const { return m_mtxProj; }
//--------------------------------------------------------------------------------
inline const DirectX::XMFLOAT4X4 Camera::GetViewProjection() const { return m_mtxViewProj; }
//--------------------------------------------------------------------------------