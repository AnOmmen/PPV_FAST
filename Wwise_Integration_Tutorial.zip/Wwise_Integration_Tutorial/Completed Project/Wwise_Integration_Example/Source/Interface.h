#pragma once
//--------------------------------------------------------------------------------
#define CREATE_INTERFACE(e) struct __declspec(novtable) e