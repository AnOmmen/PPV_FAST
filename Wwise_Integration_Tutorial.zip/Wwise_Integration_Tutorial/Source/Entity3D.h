//--------------------------------------------------------------------------------
// Entity3D
// Written By: Justin Murphy
//
// very simple entity class holding a transform to represent 
// position and orientation of an object in 3D space
//--------------------------------------------------------------------------------
#ifndef Entity3D_h
#define Entity3D_h
//--------------------------------------------------------------------------------
#include <directxmath.h>

//--------------------------------------------------------------------------------
class Entity3D {
public:
	Entity3D( );
	virtual ~Entity3D( );
	DirectX::XMFLOAT4X4 m_mWorld; //initialized to identity

	const DirectX::XMFLOAT3 * GetPosition() const;
	const DirectX::XMFLOAT3 * GetYAxis() const;
	const DirectX::XMFLOAT3 * GetZAxis() const;

	void SetPosition(const DirectX::XMFLOAT3 pos);
	void SetXAxis(const DirectX::XMFLOAT3 xAxis);
	void SetYAxis(const DirectX::XMFLOAT3 yAxis);
	void SetZAxis(const DirectX::XMFLOAT3 zAxis);
};
#include "Entity3D.hpp"
//--------------------------------------------------------------------------------
#endif // Entity3D_h
//--------------------------------------------------------------------------------